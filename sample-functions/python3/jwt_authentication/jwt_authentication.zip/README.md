# EdgeFunctions Function Layout

An EdgeFunctions function must export a handler as the entry point for the application.  This function uses the standard naming convention of `index.handler`.

# Function Description

JWT Authentication proxy function.

The function takes in an HTTP request forwarded from EdgePrism. Validates the JWT Authorization header then proxies the request and returns the response.

The function does simple HMAC JWT authorization and you can set your HMAC secret with the environment variables `JWT_SECRET` inside the function

The function gets the JWT authorization token from the request header named Authorization.

In order to create your own zip archive, you need to add the libraries requests and PyJWT to the package.  This can done using the following commands:
- $ pip install --target <path_to_function_folder> pyjwt
- $ pip install --target <path_to_function_folder> requests

Or on ubuntu distrubutions you will need to add the --system flag:
- $ pip install --system --target <path_to_function_folder> pyjwt
- $ pip install --system --target <path_to_function_folder> requests


## Request Paramaters

Use standard EP Invoke request. Will proxy to the `http://{host}:{path}` with the specified HTTP `{method}` set in the EP Invoke request and copy all headers and query params.

Optional Parameters:
- xLLnwHost = host name of proxy request
- xLlnwPath = path name of proxy rqeuest
- xLlnwHttpMethod =  request method to be made (e.g put, post, get, delete)

## Environment Variables

Required:
- JWT_SECRET = HMAC secret used to validate the signature in the JWT authorization token


## Returns

If JWT is valid will proxy request and return result.

If JWT invalid returns a 401.