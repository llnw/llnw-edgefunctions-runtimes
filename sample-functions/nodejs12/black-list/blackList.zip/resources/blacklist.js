module.exports = {
  'example1.com' : 1,
  'example2.com' : 1,
  'example3.com' : 1
};