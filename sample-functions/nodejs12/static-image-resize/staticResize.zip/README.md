# FaaS Function Layout

A FaaS function must export a handler as the entry point for the application.  This function uses the standard naming convention of index.handler.

# Function Description

Image resize function.  Returns and stores resized image in Origin Storage

Image resize leveraging Sharp https://sharp.dimens.io/en/stable/

This module supports reading JPEG, PNG, WebP, TIFF, GIF and SVG images.

Output images can be in JPEG, PNG, WebP and TIFF formats as well as uncompressed raw pixel data.

## Environment Vars

Required: One of the follow authentication methods:

### Token

  LLNW_USERNAME: string - origin storage username
  LLNW_PASSWORD: string - origin storage password

### HMAC

  HMAC_ACCESS: origin storage access key
  HMAC_SECRET: origin storage secret key

## Arguments

required request parameters:

* url  = original image url - url should NOT contain request parameters as they may cause conflicts with function
* path = path in storage where resized image will be placed

optional request parameters:

* join = bool: if set this will join the image url path to the specified storage path url
  * ie: ?url=http://foo.com/bar/baz.png&path=/images will create /images/bar/baz.png in storage account provided
* fmt  = format: string - options: 'png', 'jpeg', 'webp' and 'tiff' default is png
* fmt  = format: string - options: 'png', 'jpeg', 'webp' and 'tiff' default is png
* fit  = fit: string - options: 'cover', 'contain', 'fill', 'inside', 'outside', 'entropy', 'attention' default cover
* pos  = position: string - options: 'centre' 'top' 'right' 'left' 'bottom' 'left,top' etc default 'centre'
* hex  = hex: string - background color: 'ffffff,0.8'


## Returns

binary buffer